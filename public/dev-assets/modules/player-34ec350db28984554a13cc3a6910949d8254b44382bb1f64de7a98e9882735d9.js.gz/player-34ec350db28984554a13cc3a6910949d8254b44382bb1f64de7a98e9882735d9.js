const player = (num) => {
  const playerNumber = num;

  return {
    playerNumber
  };
};

export default player;
